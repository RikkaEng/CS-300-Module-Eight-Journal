//============================================================================
// Name        : ProjectTwo.cpp
// Author      : Rikka Eng
// Description : Lab 7 - 1 Project Two
//============================================================================

#include <iostream>
#include <vector>
#include <string>
#include <climits> // For UINT_MAX
#include <fstream>
#include <sstream>
#include <string>
#include <algorithm> // For std::sort
#include <limits> // Alternatively for UINT_MAX
#include "CSVparser.hpp"

using namespace std;

//===================================================================
// Struct: Course
// Purpose: To hold and manage course information, including course number, 
// title, and any associated prerequisites.
//===================================================================
struct Course {
	string courseNumber;			// ex: CS101, course number
	string courseTitle;				// ex: Intro to Computer Science, course title
	vector<string> prerequisites;	// List of prerequisites
	Course() {}		// Default Constructor for initializeation of a course
	Course(string number, string title, vector<string> prereqs) :
		courseNumber(number), courseTitle(title), prerequisites(prereqs) {}
};

// Hash table class definition
class HashTable {
private:
	struct Node {
		Course course;
		unsigned int key;
		Node* next;
		// Default constructor'
		Node() {
			key = UINT_MAX;
			next = nullptr;
		}
		// Initialize with a course
		Node(Course aCourse) : Node() {
			course = aCourse;
		}
		// Initialize with a course and a key
		Node(Course aCourse, unsigned int aKey) : Node(aCourse) {
			key = aKey;
		}
	};
	vector<Node> nodes;
	unsigned int tableSize;
	unsigned int hash(const string& key);

public:
	HashTable();
	HashTable(unsigned int size);
	~HashTable();
	void loadCourses(string csvPath);
	void Insert(Course course);
	bool isEmpty();
	Course Search(string courseNumber);

	vector<Course> getAllCourses();
	void sortAndPrintCourses();
};


// Initializes the hash table with a default size of 179 buckets. 
HashTable::HashTable() {
	tableSize = 179;			// default table size 179
	nodes.resize(tableSize);	// Resize the vector of nodes to 
}

// Initializes the hash table with a customer size provided,
// allows for more control of the hash table.
HashTable::HashTable(unsigned int size) {
	tableSize = size;		 // Set the table size
	nodes.resize(tableSize);
}

// Destructor
HashTable::~HashTable() {
	nodes.clear();
}

//Hash function to calculate the hash value of a given key (course number)
unsigned int HashTable::hash(const string& key) {
	unsigned int hashValue = 0;
	for (char ch : key) {
		hashValue = hashValue * 31 + ch;
	}
	return hashValue % tableSize;
}

// Inserts a new course into the hash table.
void HashTable::Insert(Course course) {
	// Create  the key using courseNumber
	unsigned int key = hash(course.courseNumber);

	// Retrieve the node using the key
	Node* prevNode = &nodes[key];

	//  If no entry is found for the course, insert it.
	if (prevNode->key == UINT_MAX) {
		prevNode->key = key;
		prevNode->course = course;
	}
	else {
		// Handle colisions by chaining
		Node* newNode = new Node(course, key);
		newNode->next = prevNode->next;
		prevNode->next = newNode;
	}
}


//  Loads course data from a CSV file and inserts each course into the hash table. 
void loadCourses(string csvPath, HashTable& table) {
	// Open the CSV file using ifstream
	ifstream file(csvPath);
	string line;

	// Read the file line by line
	while (getline(file, line)) {
		// Use stringstream to parse the lines
		stringstream ss(line);
		string courseNumber, courseTitle, prereq;
		vector<string> prerequisites;

		// Read course number and title
		getline(ss, courseNumber, ',');
		getline(ss, courseTitle, ',');

		// read the remaining fields as prerequisites
		while (getline(ss, prereq, ',')) {
			prerequisites.push_back(prereq);
		}

		// Create a new Course object with the parsed data
		Course course(courseNumber, courseTitle, prerequisites);

		// Insert the course into the hash table
		table.Insert(course);
	}
}

// Retrieves a list of all courses stored in the hash table,  mainly used for sortAndPrintCourses
vector<Course> HashTable::getAllCourses() {
	vector<Course> courseList;
	// Iterate over all buckets in the hash table
	for (const Node& node : nodes) {
		const Node* currentNode = &node;

		// Traverse the chain of nodes (linked list ) in each bucket
		while (currentNode != nullptr && currentNode->key != UINT_MAX) {
			courseList.push_back(currentNode->course);
			currentNode = currentNode->next;
		}
	}
	return courseList;
}

// Retrieves all courses from the hash table, sorts them
// alphanumerically by course number, and then prints the sorted list
// of courses with their numbers and titls.
void HashTable::sortAndPrintCourses() {
	// Retrieve all courses from the hash table
	vector<Course> courseList = getAllCourses();

	// Sort the courses based on courseNumber (alphanumeric order0
	sort(courseList.begin(), courseList.end(), [](const Course& a, const Course& b) {
		return a.courseNumber < b.courseNumber;
		});

	// Print sorted course list
	for (const Course& course : courseList) {
		cout << "Course Number: " << course.courseNumber << ", Title: " << course.courseTitle << endl;
	}
}

// Checks if the hash table is empty. Used for a edge case.
bool HashTable::isEmpty() {
	// Check if all nodes in the hash table are unintiailized
	for (const Node& node : nodes) {
		if (node.key != UINT_MAX) {
			return false;
		}
	}
	return true;
}

// Searches for a course in the hash table by its course number.
// has Chaining of nodes compatability
Course HashTable::Search(string courseNumber) {
	// Create the key using courseNumber 
	unsigned int key = hash(courseNumber);

	// Retrieve the node at the hashed index
	Node* currentNode = &nodes[key];

	// Traver the cahin of nodes at this bucket
	while (currentNode != nullptr && currentNode->key != UINT_MAX) {
		if (currentNode->course.courseNumber == courseNumber) {
			return currentNode->course;
		}
		currentNode = currentNode->next;
	}

	// If course not found, return a dummy Course object with an empty courseNumber
	return Course();
}

// Main menu
void displayMenu() {
	cout << "===========================================" << endl;
	cout << "Menu Options:" << endl;
	cout << "1. Load course data from file" << endl;
	cout << "2. Print Course list in alphanumeric order" << endl;
	cout << "3. Print course information" << endl;
	cout << "9. Exit" << endl;
	cout << "Enter your choice: ";
}

// Main method
int main() {
	// Creates a hash table to store course data
	HashTable courseTable;	
	string filename;
	int choice;

	// Loop to navigate main menu
	while (true) {
		displayMenu();
		cin >> choice;
		cout << "===========================================" << endl << endl;
		// Switch loop to handle user choices
		switch (choice) {
		case 1: { // Load Course data into hash table
			cout << "Loading Course Data into HashTable..." << endl;
			loadCourses("CS 300 ABCU_Advising_Program_Input.csv", courseTable);  
			cout << "Complete!" << endl << endl;	// Competion indicator
			break;
		}

		case 2:	// Print all courses in alphanumeric order
			if (courseTable.isEmpty()) { // Edge case is user forgot to load course data
				cout << "No data in course:" << endl;
				cout << "Please Load the course data into the system (1):" << endl;
			}
			else {
				cout << "Printing Alphanumerically: " << endl;
				courseTable.sortAndPrintCourses(); // Sorting and Printing

			}
			cout << endl;
			break;

		case 3: {  // Case 3: look up course and print its information
			cout << "What course do you want to know about? (Course Number): ";
			string courseNumber;  
			cin >> courseNumber;
			Course course = courseTable.Search(courseNumber);
			if (course.courseNumber.empty()) {
				// Course not found edge case
				cout << "Course not found." << endl;
			}
			else {
				// Print course information
				cout << "Course Number: " << course.courseNumber << " ,";
				cout << " Course Title: " << course.courseTitle << endl;

				// Print prerequisites, if any
				bool hasValidPrerequisites = false;
				for (const string& prereq : course.prerequisites) {
					if (!prereq.empty()) {
						hasValidPrerequisites = true;
						break;
					}
				}
				if (!hasValidPrerequisites) {
					cout << "No prerequisites for this course." << endl;
				}
				else {
					cout << "Prerequisite(s): ";
					for (size_t i = 0; i < course.prerequisites.size(); ++i) {
						cout << course.prerequisites[i];
						if (i < course.prerequisites.size() - 1) {
							cout << ", ";
						}
					}
					cout << endl;
				}
			}
			cout << endl;
			break;
		}

		case 9:
			// Exit the program
			cout << "Exiting program." << endl;
			return 0;

		default:
			// invalid menu option
			cout << "Invalid option." << endl;
		}
	}
}